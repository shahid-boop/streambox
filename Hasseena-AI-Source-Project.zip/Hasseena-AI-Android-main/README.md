# Hasseena AI — Android project

Hasseena AI is a Kotlin/Jetpack Compose Android assistant project. This repository includes the Visual Lens camera/photo/video flow and an OpenGL ES 2.0 3D preview with selectable stylized scenes/effects and a lightweight GLB / embedded-buffer glTF triangle-mesh importer.

## Build environment

The current project configuration was prepared for the author's Termux Android environment. It currently uses:

- Gradle wrapper: 9.6.0
- Android Gradle Plugin: 9.1.1
- Java 21 in the Termux environment
- Android SDK configuration in `local.properties`
- A Termux-specific AAPT2 override in `gradle.properties`

On the configured Termux installation, open the project directory and run:

```sh
./gradlew --stop
./gradlew :app:assembleDebug
```

If moving this project to another device or Android Studio, update `local.properties` to that machine's SDK path and remove or replace the Termux-only `android.aapt2FromMavenOverride` setting with an AAPT2 binary compatible with the build host. Do not copy local SDK paths from another machine.

## API keys and Firebase

Review `.env.example` and the existing API Key Manager implementation. Keep real API keys out of source control. Firebase sign-in/cloud features also require a Firebase project configuration matching the app's package name and the appropriate console settings.

## Visual Lens rendering scope

The current renderer is OpenGL ES 2.0 with shader-based diffuse/specular/rim lighting and stylized glow. The lightweight importer supports triangle primitives with FLOAT `POSITION` / optional `NORMAL` attributes, unsigned scalar indices, GLB binary buffers, or embedded base64 data buffers. It does not yet implement complete glTF scene/node transforms, skins/animations, texture/material import, sparse accessors, external `.gltf` buffer files, full PBR/HDR environment lighting, shadow maps, or live AR depth compositing. Device/build testing is required before release.


## Targeted Upgrade (2026-10-14)
- Added a File Workspace screen for SAF-based file import, code/text entry, individual export, and ZIP export.
- Added a user-enabled floating Orb overlay service (requires Android "Display over other apps" permission).
- Improved smart AI routing to prefer configured keys and catalog-supported vision/research models.
- Improved GLTF/GLB scene-node transform handling.
- See `UPGRADE_IMPLEMENTATION_REPORT_2026-10-14.md` for verification and current limitations.
