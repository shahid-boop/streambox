HASSEENA AI — COMBINED DARK ROMANTIC VOICE + SIX MODEL UPDATE

Included voice work
- ElevenLabs online voice integration
- Manual ElevenLabs API key and five selectable voice packs in Settings: Charmion, Hasseena Custom, Tiffany, Aurora, and Nyx
- Each pack stores its own Voice ID; the actual Voice IDs must be copied from the user's ElevenLabs account. Aurora and Nyx are custom pack labels, not pre-created ElevenLabs voices.
- Android Keystore encrypted storage for the ElevenLabs API key
- Android TTS fallback when online voice is unavailable
- Sentence-queue streaming and stop/interrupt support (Barge-In)

Selected model integrations
- NVIDIA Nemotron 3.5 Lightning — NVIDIA NIM model ID `nvidia/nemotron-3.5-lightning-30b-a3b`; NVIDIA lists a free trial endpoint, subject to account access and quota.
- NVIDIA Nemotron 3 Ultra — OpenRouter ID `nvidia/nemotron-3-ultra-550b-a55b` (paid).
- NVIDIA Nemotron 3 Super — OpenRouter ID `nvidia/nemotron-3-super-120b-a12b:free` (free endpoint when available; rate limits apply).
- Google Gemma 4 31B — OpenRouter ID `google/gemma-4-31b-it:free` (free endpoint when available).
- Qwen 3.8 27B — OpenRouter ID `qwen/qwen3.8-27b:free` (free endpoint when available).
- Kimi K2.6 — OpenRouter ID `moonshotai/kimi-k2.6` (paid; not a guaranteed free endpoint).

Cost safety: Smart auto-routing uses a non-fast OpenRouter candidate other than paid Nemotron Ultra for complex OpenRouter requests. Nemotron Ultra remains available when explicitly selected in Manual Provider/Model mode. Provider pricing and availability can change.

Setup
- In Settings > AI & Router, save an OpenRouter API key for OpenRouter models, or a separate NVIDIA NIM key for Nemotron 3.5 Lightning.
- In Settings > Orb & Voice, save the ElevenLabs API key. Select each pack and enter that saved voice's own ElevenLabs Voice ID; then select the pack to use. Do not paste API keys into chat or hard-code them in source files.
- Voice timbre (deep/husky/romantic) depends on the chosen ElevenLabs voice; the app cannot guarantee a specific voice style independently of the selected Voice ID.
- Existing non-OpenRouter providers and their catalog entries are retained.

Validation
- ZIP integrity was checked after the corrections.
- Model IDs and pricing/access labels were checked against official provider documentation on 2026-10-13.
- An Android Gradle build was NOT run in this packaging environment: Gradle distribution download failed because network DNS was unavailable. Install/build/runtime behavior still requires device-side build verification.

Additional AI models added (API key required in Settings):
- Google Gemini 3.8 Flash — model ID `gemini-3.8-flash`; Google AI Studio free-tier access and quotas depend on current account/model availability.
- GPT-OSS 120B via Groq — model ID `openai/gpt-oss-120b`; Groq publishes token pricing, so do not treat it as guaranteed free.
These entries are selectable through the existing provider/model selector. No API keys are embedded in source.

Additional requested models included in this project package:
- Kimi K2.6 — OpenRouter model ID `moonshotai/kimi-k2.6` (paid; requires OpenRouter key).
- NVIDIA Nemotron 3.5 Lightning — NVIDIA NIM model ID `nvidia/nemotron-3.5-lightning-30b-a3b` (NVIDIA lists a free trial endpoint; requires NVIDIA key and account quota).
- Kimi is selectable under OpenRouter; Nemotron 3.5 Lightning is selectable under NVIDIA NIM. No keys are bundled.
- The model catalog currently contains 23 selectable model entries across the listed providers. Provider access, free quotas, and model IDs may change.
