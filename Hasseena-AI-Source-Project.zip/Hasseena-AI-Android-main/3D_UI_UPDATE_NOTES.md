# Hasseena AI — 3D-style UI update

This update layers a shared futuristic visual system over the existing Jetpack Compose app without replacing its existing navigation or feature callbacks.

## Included
- Full-screen dark navy/cyan/violet ambient gradient backdrop shared behind all authenticated destinations.
- Subtle holographic grid and orbital rings, drawn with Compose Canvas (no new third-party dependency).
- Floating glass-style bottom navigation with cyan outline and rounded geometry.
- Preserves existing voice orb, chat, Visual Lens, Research, Control Center, Settings, Google/Firebase auth, and current provider routing code.
- Includes the optional OpenRouter free-tier model notes from `FREE_AI_MODELS_AND_MEDIA.md`.

## Important scope notes
- This is a 3D-inspired / holographic 2.5D Compose treatment, not a full real-time 3D engine. No new 3D engine or large dependency was added, to keep the app lightweight on Android devices.
- The model notes document OpenRouter example IDs; model availability and free quotas can change.
- Image generation and video generation are not falsely represented as working features: those require separate provider integrations, quota checks, generation UI, and result handling.
- Build verification could not be completed in this environment because Gradle wrapper download requires network access. Compile and test in Termux before installing the APK.
