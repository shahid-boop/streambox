# Hasseena AI — OpenGL ES 3D Lens implementation

## Added in this update
- Procedural 3D sphere mesh rendered by Android OpenGL ES 2.0 (not a static image).
- Perspective camera projection and a 24-bit depth buffer for real 3D depth testing.
- Per-vertex normals with shader-based diffuse/specular lighting and Fresnel-style cyan/violet rim lighting.
- Continuous rotation and lifecycle pause when the composable is removed.
- Integrated the renderer into the existing Visual Lens screen without removing the camera, Photo Picker, video preview, OCR prompts, or vision-result UI.

## Important limits
- This is a procedural holographic sphere model, not a downloaded artist-made GLB/GLTF model.
- Lighting is real-time shader lighting, but not a full physically based rendering (PBR) pipeline with HDR environment maps, shadow maps, or ray-traced reflections.
- The camera uses a perspective projection. It does not use the phone's depth sensor/AR depth API.
- Build/device verification could not be completed in this environment because the Gradle wrapper needs Gradle 9.6.0 from services.gradle.org and network access is unavailable. Build on the user's Termux setup before treating this as release-ready.


## Rendering enhancement status (2026-10-11)
The GLES2 preview now has scene-specific metallic/roughness presets, Schlick Fresnel, GGX-style specular response, a procedural studio reflection approximation and tone mapping. This is a lightweight stylized approximation, not full image-based PBR. HDR environment textures, glTF node transforms/material textures/animations, shadow-map rendering, a separate bloom framebuffer, and ARCore camera/depth compositing are still future implementation stages and must not be advertised as finished.
