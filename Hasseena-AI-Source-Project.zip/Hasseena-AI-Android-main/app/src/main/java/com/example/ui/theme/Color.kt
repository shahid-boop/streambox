package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBackground = Color(0xFF060911)
val ObsidianSurface = Color(0xFF0C1220)
val ObsidianSurfaceElevated = Color(0xFF131C31)
val ObsidianSurfaceGlass = Color(0xFF19243E)

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDim = Color(0xFF0097A7)
val QuantumViolet = Color(0xFF7C4DFF)
val QuantumVioletLight = Color(0xFFB388FF)
val ElectricBlue = Color(0xFF2979FF)

val EmeraldReady = Color(0xFF00E676)
val AmberThinking = Color(0xFFFFD740)
val CoralAlert = Color(0xFFFF5252)
val SolarGold = Color(0xFFFFAB00)
val CrimsonNova = Color(0xFFFF1744)

val TextPrimary = Color(0xFFF4F7FF)
val TextSecondary = Color(0xFFA6B4D0)
val TextMuted = Color(0xFF687796)
val BorderSubtle = Color(0xFF223052)
