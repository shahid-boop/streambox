package com.example.services.memory

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class ChatMessageEntity(
    val id: Long = 0,
    val role: String, // "user", "assistant", "tool"
    val content: String,
    val providerName: String = "Local Engine",
    val modelName: String = "On-Device",
    val routeCategory: String = "LOCAL ENGINE",
    val latencyMs: Long = 0L,
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val recoveryHint: String? = null,
    val citationsSummary: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class MemoryFactEntity(
    val id: Long = 0,
    val category: String, // "PREFERENCE", "FACT", "INSTRUCTION", "HABIT"
    val content: String,
    val source: String = "User / Conversation",
    val timestamp: Long = System.currentTimeMillis()
)

data class ResponseCacheEntity(
    val normalizedQuery: String,
    val responseText: String,
    val providerName: String,
    val modelName: String,
    val timestamp: Long = System.currentTimeMillis()
)

interface HasseenaDao {
    fun observeMessages(): Flow<List<ChatMessageEntity>>
    suspend fun getRecentMessages(limit: Int): List<ChatMessageEntity>
    suspend fun insertMessage(message: ChatMessageEntity): Long
    suspend fun updateMessageContent(
        id: Long,
        content: String,
        isStreaming: Boolean,
        latencyMs: Long,
        isError: Boolean = false,
        recoveryHint: String? = null,
        citations: String? = null
    )
    suspend fun clearAllMessages()

    fun observeMemoryFacts(): Flow<List<MemoryFactEntity>>
    suspend fun getActiveMemoryFacts(): List<MemoryFactEntity>
    suspend fun insertMemoryFact(fact: MemoryFactEntity): Long
    suspend fun deleteMemoryFactById(id: Long)
    suspend fun clearAllMemoryFacts()

    suspend fun getCachedResponse(query: String): ResponseCacheEntity?
    suspend fun putCachedResponse(entry: ResponseCacheEntity)
    fun observeCacheCount(): Flow<Int>
    suspend fun clearResponseCache()
}

class HasseenaDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "hasseena_ai_assistant.db", null, 1) {

    private val messagesState = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    private val memoryFactsState = MutableStateFlow<List<MemoryFactEntity>>(emptyList())
    private val cacheCountState = MutableStateFlow(0)

    private val daoImpl = object : HasseenaDao {
        override fun observeMessages(): Flow<List<ChatMessageEntity>> = messagesState.asStateFlow()

        override suspend fun getRecentMessages(limit: Int): List<ChatMessageEntity> =
            withContext(Dispatchers.IO) {
                queryRecentMessagesInternal(limit)
            }

        override suspend fun insertMessage(message: ChatMessageEntity): Long =
            withContext(Dispatchers.IO) {
                val values = ContentValues().apply {
                    if (message.id > 0L) put("id", message.id)
                    put("role", message.role)
                    put("content", message.content)
                    put("providerName", message.providerName)
                    put("modelName", message.modelName)
                    put("routeCategory", message.routeCategory)
                    put("latencyMs", message.latencyMs)
                    put("isStreaming", if (message.isStreaming) 1 else 0)
                    put("isError", if (message.isError) 1 else 0)
                    put("recoveryHint", message.recoveryHint)
                    put("citationsSummary", message.citationsSummary)
                    put("timestamp", message.timestamp)
                }
                val id = writableDatabase.insertWithOnConflict(
                    "chat_messages",
                    null,
                    values,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
                refreshMessagesStateInternal()
                id
            }

        override suspend fun updateMessageContent(
            id: Long,
            content: String,
            isStreaming: Boolean,
            latencyMs: Long,
            isError: Boolean,
            recoveryHint: String?,
            citations: String?
        ) = withContext(Dispatchers.IO) {
            val values = ContentValues().apply {
                put("content", content)
                put("isStreaming", if (isStreaming) 1 else 0)
                put("latencyMs", latencyMs)
                put("isError", if (isError) 1 else 0)
                put("recoveryHint", recoveryHint)
                put("citationsSummary", citations)
            }
            writableDatabase.update(
                "chat_messages",
                values,
                "id = ?",
                arrayOf(id.toString())
            )
            refreshMessagesStateInternal()
        }

        override suspend fun clearAllMessages() = withContext(Dispatchers.IO) {
            writableDatabase.delete("chat_messages", null, null)
            refreshMessagesStateInternal()
        }

        override fun observeMemoryFacts(): Flow<List<MemoryFactEntity>> =
            memoryFactsState.asStateFlow()

        override suspend fun getActiveMemoryFacts(): List<MemoryFactEntity> =
            withContext(Dispatchers.IO) {
                queryMemoryFactsInternal(limit = 25)
            }

        override suspend fun insertMemoryFact(fact: MemoryFactEntity): Long =
            withContext(Dispatchers.IO) {
                val values = ContentValues().apply {
                    if (fact.id > 0L) put("id", fact.id)
                    put("category", fact.category)
                    put("content", fact.content)
                    put("source", fact.source)
                    put("timestamp", fact.timestamp)
                }
                val id = writableDatabase.insertWithOnConflict(
                    "memory_facts",
                    null,
                    values,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
                refreshMemoryFactsStateInternal()
                id
            }

        override suspend fun deleteMemoryFactById(id: Long) = withContext(Dispatchers.IO) {
            writableDatabase.delete("memory_facts", "id = ?", arrayOf(id.toString()))
            refreshMemoryFactsStateInternal()
        }

        override suspend fun clearAllMemoryFacts() = withContext(Dispatchers.IO) {
            writableDatabase.delete("memory_facts", null, null)
            refreshMemoryFactsStateInternal()
        }

        override suspend fun getCachedResponse(query: String): ResponseCacheEntity? =
            withContext(Dispatchers.IO) {
                readableDatabase.query(
                    "response_cache",
                    arrayOf("normalizedQuery", "responseText", "providerName", "modelName", "timestamp"),
                    "normalizedQuery = ?",
                    arrayOf(query),
                    null,
                    null,
                    null,
                    "1"
                ).use { cursor ->
                    if (cursor.moveToFirst()) {
                        ResponseCacheEntity(
                            normalizedQuery = cursor.getString(0),
                            responseText = cursor.getString(1),
                            providerName = cursor.getString(2),
                            modelName = cursor.getString(3),
                            timestamp = cursor.getLong(4)
                        )
                    } else {
                        null
                    }
                }
            }

        override suspend fun putCachedResponse(entry: ResponseCacheEntity) =
            withContext(Dispatchers.IO) {
                val values = ContentValues().apply {
                    put("normalizedQuery", entry.normalizedQuery)
                    put("responseText", entry.responseText)
                    put("providerName", entry.providerName)
                    put("modelName", entry.modelName)
                    put("timestamp", entry.timestamp)
                }
                writableDatabase.insertWithOnConflict(
                    "response_cache",
                    null,
                    values,
                    SQLiteDatabase.CONFLICT_REPLACE
                )
                refreshCacheCountStateInternal()
            }

        override fun observeCacheCount(): Flow<Int> = cacheCountState.asStateFlow()

        override suspend fun clearResponseCache() = withContext(Dispatchers.IO) {
            writableDatabase.delete("response_cache", null, null)
            refreshCacheCountStateInternal()
        }
    }

    init {
        refreshMessagesStateInternal()
        refreshMemoryFactsStateInternal()
        refreshCacheCountStateInternal()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS chat_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                providerName TEXT NOT NULL,
                modelName TEXT NOT NULL,
                routeCategory TEXT NOT NULL,
                latencyMs INTEGER NOT NULL,
                isStreaming INTEGER NOT NULL,
                isError INTEGER NOT NULL,
                recoveryHint TEXT,
                citationsSummary TEXT,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS memory_facts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                source TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS response_cache (
                normalizedQuery TEXT PRIMARY KEY NOT NULL,
                responseText TEXT NOT NULL,
                providerName TEXT NOT NULL,
                modelName TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS chat_messages")
        db.execSQL("DROP TABLE IF EXISTS memory_facts")
        db.execSQL("DROP TABLE IF EXISTS response_cache")
        onCreate(db)
    }

    fun hasseenaDao(): HasseenaDao = daoImpl

    private fun refreshMessagesStateInternal() {
        val list = mutableListOf<ChatMessageEntity>()
        readableDatabase.query(
            "chat_messages",
            arrayOf(
                "id", "role", "content", "providerName", "modelName",
                "routeCategory", "latencyMs", "isStreaming", "isError",
                "recoveryHint", "citationsSummary", "timestamp"
            ),
            null,
            null,
            null,
            null,
            "timestamp ASC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                list.add(
                    ChatMessageEntity(
                        id = cursor.getLong(0),
                        role = cursor.getString(1),
                        content = cursor.getString(2),
                        providerName = cursor.getString(3),
                        modelName = cursor.getString(4),
                        routeCategory = cursor.getString(5),
                        latencyMs = cursor.getLong(6),
                        isStreaming = cursor.getInt(7) != 0,
                        isError = cursor.getInt(8) != 0,
                        recoveryHint = if (cursor.isNull(9)) null else cursor.getString(9),
                        citationsSummary = if (cursor.isNull(10)) null else cursor.getString(10),
                        timestamp = cursor.getLong(11)
                    )
                )
            }
        }
        messagesState.value = list
    }

    private fun queryRecentMessagesInternal(limit: Int): List<ChatMessageEntity> {
        val list = mutableListOf<ChatMessageEntity>()
        readableDatabase.query(
            "chat_messages",
            arrayOf(
                "id", "role", "content", "providerName", "modelName",
                "routeCategory", "latencyMs", "isStreaming", "isError",
                "recoveryHint", "citationsSummary", "timestamp"
            ),
            null,
            null,
            null,
            null,
            "timestamp DESC",
            limit.toString()
        ).use { cursor ->
            while (cursor.moveToNext()) {
                list.add(
                    ChatMessageEntity(
                        id = cursor.getLong(0),
                        role = cursor.getString(1),
                        content = cursor.getString(2),
                        providerName = cursor.getString(3),
                        modelName = cursor.getString(4),
                        routeCategory = cursor.getString(5),
                        latencyMs = cursor.getLong(6),
                        isStreaming = cursor.getInt(7) != 0,
                        isError = cursor.getInt(8) != 0,
                        recoveryHint = if (cursor.isNull(9)) null else cursor.getString(9),
                        citationsSummary = if (cursor.isNull(10)) null else cursor.getString(10),
                        timestamp = cursor.getLong(11)
                    )
                )
            }
        }
        return list
    }

    private fun refreshMemoryFactsStateInternal() {
        memoryFactsState.value = queryMemoryFactsInternal(limit = null)
    }

    private fun queryMemoryFactsInternal(limit: Int?): List<MemoryFactEntity> {
        val list = mutableListOf<MemoryFactEntity>()
        readableDatabase.query(
            "memory_facts",
            arrayOf("id", "category", "content", "source", "timestamp"),
            null,
            null,
            null,
            null,
            "timestamp DESC",
            limit?.toString()
        ).use { cursor ->
            while (cursor.moveToNext()) {
                list.add(
                    MemoryFactEntity(
                        id = cursor.getLong(0),
                        category = cursor.getString(1),
                        content = cursor.getString(2),
                        source = cursor.getString(3),
                        timestamp = cursor.getLong(4)
                    )
                )
            }
        }
        return list
    }

    private fun refreshCacheCountStateInternal() {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM response_cache", null).use { cursor ->
            cacheCountState.value = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: HasseenaDatabase? = null

        fun getInstance(context: Context): HasseenaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = INSTANCE ?: HasseenaDatabase(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
