package com.example.services.cloud

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Test

class CloudSyncRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createCloudMemory_validPayload_createsDocumentAndReturnsId() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = CloudSyncRepository(firestore)

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createCloudMemory("PREFERENCE", "Prefer fast streaming responses", "User")
        }
        assertTrue(createResult.isSuccess)
        val memoryId = createResult.getOrThrow()
        assertTrue(memoryId.isNotEmpty())
    }

    @Test
    fun getUserCloudMemories_authenticatedOwner_returnsMatchingMemories() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = CloudSyncRepository(firestore)
        val memoryId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createCloudMemory("FACT", "Lives in Lahore", "Voice/Chat Command").getOrThrow()
        }

        val listResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getUserCloudMemories()
        }
        assertTrue(listResult.isSuccess)
        assertTrue(listResult.getOrThrow().map { it.id }.contains(memoryId))
    }

    @Test
    fun observeCloudMemories_authenticatedOwner_emitsRealtimeUpdates() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = CloudSyncRepository(firestore)
        val memoryId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createCloudMemory("HABIT", "Morning briefing at 8 AM", "User").getOrThrow()
        }

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeCloudMemories().first { list -> list.any { it.id == memoryId } }
        }
        assertTrue(emitted.any { it.id == memoryId })
    }

    @Test
    fun getCloudMemoryById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = CloudSyncRepository(firestore)
        val memoryId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createCloudMemory("FACT", "Alice private key note", "User").getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = CloudSyncRepository(firestore)
        val exception = assertFailsWith<FirebaseFirestoreException> {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.getCloudMemoryById(aliceUid, memoryId).getOrThrow()
            }
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, exception.code)
    }

    @Test
    fun observeCloudMemories_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = CloudSyncRepository(firestore)

        val exception = assertFailsWith<FirebaseFirestoreException> {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeCloudMemories().first()
            }
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, exception.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice@hasseena.test"
        const val BOB_EMAIL = "bob@hasseena.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
